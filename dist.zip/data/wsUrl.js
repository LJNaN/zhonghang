const wsUrl = 'ws://frp.linkvision.cloud:42142/ws/info?access_token='

window.wsUrl = wsUrl